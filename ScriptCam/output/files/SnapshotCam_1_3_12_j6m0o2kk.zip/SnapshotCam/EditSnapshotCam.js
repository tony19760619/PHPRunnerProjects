Runner.controls.EditSnapshotCam = Runner.extend(Runner.controls.Control,{
	/**
	 * Override constructor
	 * @param {Object} cfg
	 */
	required: false,
	myVal: "value of my Field: ", 
	constructor: function(cfg){		
		this.addEvent(["change", "keyup"]);		
		// call parent
		Runner.controls.EditSnapshotCam.superclass.constructor.call(this, cfg);
		this.required = this.getFieldSetting("required");
		this.myVal = this.getFieldSetting("myVal");
	
                if (this.required)
			this.addValidation("IsRequired");

                $( "input[class^='HIDE_SNAPSHOTCAM_FIELD']" ).hide();
                
                if(this.getValue() != ''){
                    SnapshotCamFile = JSON.parse(this.getValue());    
                }else{
                    SnapshotCamFile = new Array();
                    SnapshotCamFile[0] = {
                        "name":"",
                        "usrName":"SnapshotCam.png",
                        "size":1,
                        "type":'image\\/png',
                        "searchStr":"SnapshotCam.png,!:sStrEnd"
                    };
                }
	},
	isEmpty: function(){
		return this.getValue().toString()=="";
	},
        getForSubmit: function(){            
                if(SnapshotCamFile[0]['name'] == ''){
                    this.setValue('');
                }else{
                    var myJSONString = JSON.stringify(SnapshotCamFile);
                    var regex = /\\\\/g;
                    var finalData = myJSONString.replace(regex, "\\");                              
                    this.setValue(finalData);
                }
                
		if (!this.appearOnPage()){
                        //return [];
			return [this.valueElem.clone().val(this.getValue())];
		}
                //[input#value_AttachedFile_1, prevObject: n.fn.init[1], context: document]
                return [this.valueElem.clone().val(this.getValue())];
	},
	setFocus: function(){
                //tony123
		//if (!this.appearOnPage()){
		//	return [];
		//}
		return false;
	}

});

Runner.controls.constants["EditSnapshotCam"] = "EditSnapshotCam"; 



