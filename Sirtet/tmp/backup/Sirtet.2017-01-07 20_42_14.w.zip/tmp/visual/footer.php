<?php
//echo '<div align="right"><iframe align="right" width="600" height="530" scrolling="no" seamless="seamless" frameborder=0 src="http://www.sirtet.co.uk/phpchat/chatbox.php"></iframe></div>';
?>

