
<P align="center">Use <B>admin/admin</B> to login. This header can be found in 
Header item on the Visual Editor 
screen.</P>
